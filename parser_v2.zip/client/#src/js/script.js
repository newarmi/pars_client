// const sendData = async (url, data) => {
// 	const response = await fetch(url, {
// 		method: 'POST',
// 		body: JSON.stringify(data),
// 		// mode: 'no-cors'
// 	})
// 	return response.text();
// 	// let content = JSON.parse(contentText);
// 	// out = 'пипа';
// 	// content.forEach((elem) => {
// 	// 	console.log(elem.yes);
// 	// 	console.log(elem.articul);

// 	// 	if (elem.yes) {
// 	// 		out += `<div class="elem">`;
// 	// 		out += `<p class="elem__articul">Проверено: ${elem.articul}</p>`;
// 	// 		out += `<p class="elem__articul">Запрос: ${elem.zap}</p>`;
// 	// 		out += `<p class="elem__mest">Место на вкладке: ${elem.mest}</p>`;
// 	// 		out += `<p class="elem__vkl">Вкладка: ${elem.vkl}</p>`;
// 	// 		out += `<p class="elem__level">Карточек проверено всего: ${elem.level}</p>`;
// 	// 		out += `</div>`;
// 	// 	} else {
// 	// 		out += `<div class="elem">`;
// 	// 		out += `<p class="elem__articul">Проверено: ${elem.articul}</p>`;
// 	// 		out += `<p class="elem__articul">Запрос: ${elem.zap}</p>`;
// 	// 		out += `</div>`;
// 	// 	}
// 	// })
// 	// document.querySelector('.out').innerHTML(out)
// }
let add = `<div class="articul-check__input"><input type="text" id="reqst" placeholder="Запрос"></div>`
document.querySelector('#add').addEventListener('click', function (e) {
	e.preventDefault();
	document.querySelector('.input-conteiner').insertAdjacentHTML('beforeend', add);
})
document.querySelector('input[type=submit]').addEventListener('click', function (e) {
	let send = [];
	let resp = []
	e.preventDefault();
	const inputsCont = document.querySelector('.input-conteiner');
	const inputs = inputsCont.querySelectorAll('input');
	inputs.forEach(elem => {
		if (elem.getAttribute('id') == 'articul') {
			send.push(elem.value);
		} else {
			resp.push(elem.value);
		}
	})
	send.push(resp);
	// http://localhost:3000/
	// sendData('http://localhost:3000/', send)
	// 	.then((data) => {
	// 		let content = JSON.parse(data);
	// 		console.log(content);
	// 		out = '';
	// 		content.forEach((elem) => {
	// 			console.log(elem.yes);
	// 			console.log(elem.articul);
	// 			if (elem.yes) {
	// 				out += `<div class="elem">`;
	// 				out += `<p class="elem__articul">Проверено: ${elem.articul}</p>`;
	// 				out += `<p class="elem__articul">Запрос: ${elem.zap}</p>`;
	// 				out += `<p class="elem__mest">Место на вкладке: ${elem.mest}</p>`;
	// 				out += `<p class="elem__vkl">Вкладка: ${elem.vkl}</p>`;
	// 				out += `<p class="elem__level">Карточек проверено всего: ${elem.level}</p>`;
	// 				out += `</div>`;
	// 			} else {
	// 				out += `<div class="elem">`;
	// 				out += `<p class="elem__articul">Проверено: ${elem.articul}</p>`;
	// 				out += `<p class="elem__articul">Запрос: ${elem.zap}</p>`;
	// 				out += `<p class="elem__articul">Ненайдено!</p>`
	// 				out += `</div>`;
	// 			}
	// 		})
	// 		console.log(out);

	// 		document.querySelector('.out').innerHTML = out;

	// 	});
	out = '';
	out += `<div class="elem">`;
	out += `<p class="elem__articul">Проверено: 12</p>`;
	out += `<p class="elem__articul">Запрос: Поп ит</p>`;
	out += `<p class="elem__mest">Место на вкладке: 15</p>`;
	out += `<p class="elem__vkl">Вкладка: 16</p>`;
	out += `<p class="elem__level">Карточек проверено всего: 179</p>`;
	out += `</div>`;
	document.querySelector('.out').innerHTML = out;
})