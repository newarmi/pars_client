const axios = require('axios');
const cheerio = require('cheerio');

const http = require('http');

const parse = async (serch, art) => {
	const searchDecode = encodeURI(serch)
	console.log(searchDecode);

	let res = []
	let obj = {
		articul: art,
		zap: serch,
		yes: false,
	};
	const getHTML = async (url) => {
		const { data } = await axios.get(url);
		return cheerio.load(data);
	};
	for (let a = 1; a <= 50; a++) {
		const $ = await getHTML(`https://www.wildberries.ru/catalog/0/search.aspx?search=${searchDecode}&xsearch=true&page=${a}`);

		let end = $('a.pagination-next').html();
		if (end) {

		} else {
			a = 51;
		}
		$('.j-card-item').each((i, elem) => {
			const articul = $(elem).data('popup-nm-id');
			res.push(articul);
		});
	};
	res.forEach((elem, a) => {
		if (+elem == +art) {
			obj = {
				articul: art,
				zap: serch,
				yes: true,
				level: (a + 1),
				vkl: (Math.floor((a + 1) / 100) + 1),
				mest: ((a + 1) % 100),
			}
		}
	})
	return obj;
};

// parse('поп ит', 26259909).then(mas => console.log(mas));
const compare = async (mas) => {
	let res = [];
	let i = 0;

	const wait = () => {
		while (i <= (mas.length - 1)) {

			mas[i + 1].forEach(async elem => {
				res.push(parse(elem, mas[i]));
			});

			i = i + 2;

		}
		let allp = Promise.all(res)
		return allp
	}
	return await wait();
};
const vikup = [
	26259909, ['поп ит', 'пупырка', 'Pop it'],
	22953751, ['поп ит', 'пупырка', 'Pop it'],
	// 	9879353, ['шарф женский', 'шелковый шарф', 'шарф платок палантин', 'шарф палантин', 'шарфы, платки - палантины женские',
	//		'шелковый палантин', 'шарф палантин', 'шарфик женский летний', 'палантин платок', 'шарфы женские'],
	// 	9879354, ['шарф женский', 'шелковый шарф', 'шарф платок палантин', 'шарф палантин', 'шарфы, платки - палантины женские',
	// 		'шелковый палантин', 'шарф палантин', 'шарфик женский летний', 'палантин платок', 'шарфы женские'],
	// 	9879355, ['шарф женский', 'шелковый шарф', 'шарф платок палантин', 'шарф палантин', 'шарфы, платки - палантины женские',
	// 		'шелковый палантин', 'шарф палантин', 'шарфик женский летний', 'палантин платок', 'шарфы женские'],
	// 	9879356, ['шарф женский', 'шелковый шарф', 'шарф платок палантин', 'шарф палантин', 'шарфы, платки - палантины женские',
	// 		'шелковый палантин', 'шарф палантин', 'шарфик женский летний', 'палантин платок', 'шарфы женские'],
	// 	9879357, ['шарф женский', 'шелковый шарф', 'шарф платок палантин', 'шарф палантин', 'шарфы, платки - палантины женские',
	// 		'шелковый палантин', 'шарф палантин', 'шарфик женский летний', 'палантин платок', 'шарфы женские'],
	// 	9879358, ['шарф женский', 'шелковый шарф', 'шарф платок палантин', 'шарф палантин', 'шарфы, платки - палантины женские',
	// 		'шелковый палантин', 'шарф палантин', 'шарфик женский летний', 'палантин платок', 'шарфы женские'],
	// 	9879359, ['шарф женский', 'шелковый шарф', 'шарф платок палантин', 'шарф палантин', 'шарфы, платки - палантины женские',
	// 		'шелковый палантин', 'шарф палантин', 'шарфик женский летний', 'палантин платок', 'шарфы женские'],
	// 	9879360, ['шарф женский', 'шелковый шарф', 'шарф платок палантин', 'шарф палантин', 'шарфы, платки - палантины женские',
	// 		'шелковый палантин', 'шарф палантин', 'шарфик женский летний', 'палантин платок', 'шарфы женские'],
]
// compare(vikup).then(data => {
// 	console.log(data);
// })
http.createServer((request, response) => {
	let body = '';
	request.on('data', chunk => {
		body += chunk.toString();
	});
	request.on('end', () => {
		compare(JSON.parse(body))
			.then(data => {
				console.log(data);
				response.writeHead(200, { 'Content-Type': 'application/json', "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Credentials": true })
				response.end(JSON.stringify(data))
			});



	});

}).listen(3000)
